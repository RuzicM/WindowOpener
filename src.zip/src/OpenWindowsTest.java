import java.awt.*;
import java.io.File;
import java.io.IOException;

public class OpenWindowsTest {

    static String[] strings;
    static File file;

    public static void main(String[] args) {

        try {
            File[] paths;
            paths = File.listRoots();

            for (File path : paths) {
                strings = path.list();

                while (true) {

                    for (int x = 1; x < strings.length; x++) {

                        file = new File(path + strings[x]);

                        if (file.isDirectory()) {
                            Desktop desktop = Desktop.getDesktop();

                            File fileToOpen = new File(path + strings[x]);
                            desktop.open(fileToOpen);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}